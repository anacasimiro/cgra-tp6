function MyRobot(scene, minS, maxS, minT, maxT) {
	CGFobject.call(this,scene);

	this.cylinder = new MyCylinder(scene, 30, 2);
	this.semisphere = new MyLamp(scene, 30, 20);
	this.circle = new MyShape(scene, 30);
	this.rightWheel = new MyWheel(scene, 30);
	this.leftWheel = new MyWheel(scene, 30);

	this.minS = minS || 0;
	this.maxS = maxS || 1;
	this.minT = minT || 0;
	this.maxT = maxT || 1;

	this.x = 7.5;
	this.z = 7.5;
	this.angle = 270;


	// Body Appearances

	this.bodyAppearances = [];

	this.bodyAppearances[0] = new CGFappearance(scene);
	this.bodyAppearances[0].loadTexture('../resources/images/robot/body_iron.png');

	this.bodyAppearances[1] = new CGFappearance(scene);
	this.bodyAppearances[1].loadTexture('../resources/images/robot/body_hulk.png');

	this.bodyAppearances[2] = new CGFappearance(scene);
	this.bodyAppearances[2].loadTexture('../resources/images/robot/body_captain.png');


	// Head Appearances

	this.headAppearances = [];

	this.headAppearances[0] = new CGFappearance(scene);
	this.headAppearances[0].loadTexture('../resources/images/robot/head_iron.png');

	this.headAppearances[1] = new CGFappearance(scene);
	this.headAppearances[1].loadTexture('../resources/images/robot/head_hulk.png');

	this.headAppearances[2] = new CGFappearance(scene);
	this.headAppearances[2].loadTexture('../resources/images/robot/head_captain.png');


	// Arm Appearances

	this.armAppearances = [];

	this.armAppearances[0] = new CGFappearance(scene);
	this.armAppearances[0].loadTexture('../resources/images/robot/arm_iron.png');

	this.armAppearances[1] = new CGFappearance(scene);
	this.armAppearances[1].loadTexture('../resources/images/robot/arm_hulk.png');

	this.armAppearances[2] = new CGFappearance(scene);
	this.armAppearances[2].loadTexture('../resources/images/robot/arm_captain.png');


	// Wheel Appearances

	this.wheelAppearances = [];

	this.wheelAppearances[0] = new CGFappearance(scene);
	this.wheelAppearances[0].loadTexture('../resources/images/robot/wheel_iron.png');

	this.wheelAppearances[1] = new CGFappearance(scene);
	this.wheelAppearances[1].loadTexture('../resources/images/robot/wheel_hulk.png');

	this.wheelAppearances[2] = new CGFappearance(scene);
	this.wheelAppearances[2].loadTexture('../resources/images/robot/wheel_captain.png');


	// Clean Appearances

	this.cleanAppearances = [];

	this.cleanAppearances[0] = new CGFappearance(scene);
	this.cleanAppearances[0].loadTexture('../resources/images/robot/clean_iron.png');

	this.cleanAppearances[1] = new CGFappearance(scene);
	this.cleanAppearances[1].loadTexture('../resources/images/robot/clean_hulk.png');

	this.cleanAppearances[2] = new CGFappearance(scene);
	this.cleanAppearances[2].loadTexture('../resources/images/robot/clean_captain.png');


	this.initBuffers();

}

MyRobot.prototype = Object.create(CGFobject.prototype);
MyRobot.prototype.constructor = MyRobot;

MyRobot.prototype.move = function(direction, speed) {

	if ( direction == 1 ) {
		this.x += speed * Math.sin(this.angle * degToRad);
		this.z += speed * Math.cos(this.angle * degToRad);
		this.leftWheel.angle += speed * 80;
		this.rightWheel.angle -= speed * 80;

	} else {
		this.x -= speed * Math.sin(this.angle * degToRad);
		this.z -= speed * Math.cos(this.angle * degToRad);
		this.leftWheel.angle -= speed * 80;
		this.rightWheel.angle += speed * 80;
	}

};

MyRobot.prototype.rotate = function(direction, speed) {

	if ( direction == 1 ) {
		this.angle -= speed * 20;
		this.leftWheel.angle += speed * 30;
		this.rightWheel.angle += speed * 30;
	} else {
		this.angle += speed * 20;
		this.leftWheel.angle -= speed * 30;
		this.rightWheel.angle -= speed * 30;
	}

};

MyRobot.prototype.initBuffers = function() {
	this.vertices = [
        0.5, 0.3, 0,
        -0.5, 0.3, 0,
		0, 0.3, 2
	];

	this.indices = [
        1, 2, 0
    ];

	this.primitiveType = this.scene.gl.TRIANGLES;

	this.normals = [
		0, 1, 0,
		0, 1, 0,
		0, 1, 0
	];

	this.texCoords = [
		this.minS, this.minT,
		this.minS, this.maxT,
		this.maxS, this.minT,
		this.maxS, this.maxT
	];

	this.initGLBuffers();
};

MyRobot.prototype.display = function() {

	// Body
	this.scene.pushMatrix();
		this.scene.translate(0, 0.3, 0);
		this.scene.pushMatrix();
			this.scene.scale(1, 1.5, 1);
			this.scene.rotate(90 * degToRad, 0, 1, 0);
			this.scene.rotate(-90 * degToRad, 1, 0, 0);
			this.bodyAppearances[this.scene.currRobotAppearance].apply();
			this.cylinder.display();
		this.scene.popMatrix();
		this.scene.pushMatrix();
			this.scene.translate(0, 3, 0);
			this.scene.rotate(-90 * degToRad, 1, 0, 0);
			this.cleanAppearances[this.scene.currRobotAppearance].apply();
			this.circle.display();
		this.scene.popMatrix();
		this.scene.pushMatrix();
			this.scene.rotate(90 * degToRad, 1, 0, 0);
		this.cleanAppearances[this.scene.currRobotAppearance].apply();
			this.circle.display();
		this.scene.popMatrix();
	this.scene.popMatrix();

	// Head
	this.scene.pushMatrix();
		this.scene.translate(0, 0.3, 0);
		this.scene.pushMatrix();
			this.scene.translate(0, 3.1, 0);
			this.scene.rotate(180 * degToRad, 0, 1, 0);
			this.scene.rotate(-90 * degToRad, 1, 0, 0);
			this.headAppearances[this.scene.currRobotAppearance].apply();
			this.semisphere.display();
		this.scene.popMatrix();
		this.scene.pushMatrix();
			this.scene.translate(0, 3.1, 0);
			this.scene.rotate(90 * degToRad, 1, 0, 0);
			this.cleanAppearances[this.scene.currRobotAppearance].apply();
			this.circle.display();
		this.scene.popMatrix();
	this.scene.popMatrix();

	// Right Arm
	this.scene.pushMatrix();
		this.scene.translate(-1.35, 2.1, 0);
		this.scene.scale(0.3, 0.3, 0.3);
		this.scene.pushMatrix();
			this.scene.scale(1, 1.5, 1);
			this.scene.rotate(-90 * degToRad, 1, 0, 0);
			this.armAppearances[this.scene.currRobotAppearance].apply();
			this.cylinder.display();
		this.scene.popMatrix();
		this.scene.pushMatrix();
			this.scene.rotate(90 * degToRad, 1, 0, 0);
			this.cleanAppearances[this.scene.currRobotAppearance].apply();
			this.semisphere.display();
		this.scene.popMatrix();
		this.scene.pushMatrix();
			this.scene.translate(0, 3, 0);
			this.scene.rotate(-90 * degToRad, 1, 0, 0);
			this.cleanAppearances[this.scene.currRobotAppearance].apply();
			this.semisphere.display();
		this.scene.popMatrix();
	this.scene.popMatrix();

	// Left Arm
	this.scene.pushMatrix();
		this.scene.translate(1.35, 2.1, 0);
		this.scene.scale(0.3, 0.3, 0.3);
		this.scene.pushMatrix();
			this.scene.scale(1, 1.5, 1);
			this.scene.rotate(-90 * degToRad, 1, 0, 0);
			this.armAppearances[this.scene.currRobotAppearance].apply();
			this.cylinder.display();
		this.scene.popMatrix();
		this.scene.pushMatrix();
			this.scene.rotate(90 * degToRad, 1, 0, 0);
			this.cleanAppearances[this.scene.currRobotAppearance].apply();
			this.semisphere.display();
		this.scene.popMatrix();
		this.scene.pushMatrix();
			this.scene.translate(0, 3, 0);
			this.scene.rotate(-90 * degToRad, 1, 0, 0);
			this.cleanAppearances[this.scene.currRobotAppearance].apply();
			this.semisphere.display();
		this.scene.popMatrix();
	this.scene.popMatrix();

	// Right Wheel
	this.scene.pushMatrix();
		this.scene.rotate(-90 * degToRad, 0, 1, 0);
		this.scene.translate(0, 0.5, 1.05);
		this.scene.scale(0.5, 0.5, 0.2);
		this.wheelAppearances[this.scene.currRobotAppearance].apply();
		this.rightWheel.display();
	this.scene.popMatrix();

	// Left Wheel
	this.scene.pushMatrix();
		this.scene.rotate(90 * degToRad, 0, 1, 0);
		this.scene.translate(0, 0.5, 1.05);
		this.scene.scale(0.5, 0.5, 0.2);
		this.wheelAppearances[this.scene.currRobotAppearance].apply();
		this.leftWheel.display();
	this.scene.popMatrix();

};